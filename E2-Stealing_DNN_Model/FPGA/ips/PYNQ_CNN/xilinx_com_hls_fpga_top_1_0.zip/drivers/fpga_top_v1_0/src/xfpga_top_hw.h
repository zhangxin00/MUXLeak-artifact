// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// axilite
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x18 : Data signal of layer_width_V
//        bit 8~0 - layer_width_V[8:0] (Read/Write)
//        others  - reserved
// 0x1c : reserved
// 0x20 : Data signal of layer_height_V
//        bit 8~0 - layer_height_V[8:0] (Read/Write)
//        others  - reserved
// 0x24 : reserved
// 0x28 : Data signal of layer_channels_in_V
//        bit 9~0 - layer_channels_in_V[9:0] (Read/Write)
//        others  - reserved
// 0x2c : reserved
// 0x30 : Data signal of layer_channels_out_V
//        bit 9~0 - layer_channels_out_V[9:0] (Read/Write)
//        others  - reserved
// 0x34 : reserved
// 0x38 : Data signal of layer_kernel_V
//        bit 1~0 - layer_kernel_V[1:0] (Read/Write)
//        others  - reserved
// 0x3c : reserved
// 0x40 : Data signal of layer_stride_V
//        bit 1~0 - layer_stride_V[1:0] (Read/Write)
//        others  - reserved
// 0x44 : reserved
// 0x48 : Data signal of layer_pad
//        bit 0  - layer_pad[0] (Read/Write)
//        others - reserved
// 0x4c : reserved
// 0x50 : Data signal of layer_relu
//        bit 0  - layer_relu[0] (Read/Write)
//        others - reserved
// 0x54 : reserved
// 0x58 : Data signal of layer_is_first_split_layer
//        bit 0  - layer_is_first_split_layer[0] (Read/Write)
//        others - reserved
// 0x5c : reserved
// 0x60 : Data signal of layer_is_second_split_layer
//        bit 0  - layer_is_second_split_layer[0] (Read/Write)
//        others - reserved
// 0x64 : reserved
// 0x68 : Data signal of layer_global_pool
//        bit 0  - layer_global_pool[0] (Read/Write)
//        others - reserved
// 0x6c : reserved
// 0x70 : Data signal of layer_mem_addr_input_V
//        bit 22~0 - layer_mem_addr_input_V[22:0] (Read/Write)
//        others   - reserved
// 0x74 : reserved
// 0x78 : Data signal of layer_mem_addr_output_V
//        bit 22~0 - layer_mem_addr_output_V[22:0] (Read/Write)
//        others   - reserved
// 0x7c : reserved
// 0x80 : Data signal of layer_mem_addr_weights_V
//        bit 22~0 - layer_mem_addr_weights_V[22:0] (Read/Write)
//        others   - reserved
// 0x84 : reserved
// 0x88 : Data signal of SHARED_DRAM
//        bit 31~0 - SHARED_DRAM[31:0] (Read/Write)
// 0x8c : reserved
// 0x90 : Data signal of weights_offset
//        bit 31~0 - weights_offset[31:0] (Read/Write)
// 0x94 : reserved
// 0x98 : Data signal of num_weights_V
//        bit 18~0 - num_weights_V[18:0] (Read/Write)
//        others   - reserved
// 0x9c : reserved
// 0xa0 : Data signal of input_offset
//        bit 31~0 - input_offset[31:0] (Read/Write)
// 0xa4 : reserved
// 0x10 ~
// 0x17 : Memory 'layer_name' (7 * 8b)
//        Word n : bit [ 7: 0] - layer_name[4n]
//                 bit [15: 8] - layer_name[4n+1]
//                 bit [23:16] - layer_name[4n+2]
//                 bit [31:24] - layer_name[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFPGA_TOP_AXILITE_ADDR_AP_CTRL                          0x00
#define XFPGA_TOP_AXILITE_ADDR_GIE                              0x04
#define XFPGA_TOP_AXILITE_ADDR_IER                              0x08
#define XFPGA_TOP_AXILITE_ADDR_ISR                              0x0c
#define XFPGA_TOP_AXILITE_ADDR_LAYER_WIDTH_V_DATA               0x18
#define XFPGA_TOP_AXILITE_BITS_LAYER_WIDTH_V_DATA               9
#define XFPGA_TOP_AXILITE_ADDR_LAYER_HEIGHT_V_DATA              0x20
#define XFPGA_TOP_AXILITE_BITS_LAYER_HEIGHT_V_DATA              9
#define XFPGA_TOP_AXILITE_ADDR_LAYER_CHANNELS_IN_V_DATA         0x28
#define XFPGA_TOP_AXILITE_BITS_LAYER_CHANNELS_IN_V_DATA         10
#define XFPGA_TOP_AXILITE_ADDR_LAYER_CHANNELS_OUT_V_DATA        0x30
#define XFPGA_TOP_AXILITE_BITS_LAYER_CHANNELS_OUT_V_DATA        10
#define XFPGA_TOP_AXILITE_ADDR_LAYER_KERNEL_V_DATA              0x38
#define XFPGA_TOP_AXILITE_BITS_LAYER_KERNEL_V_DATA              2
#define XFPGA_TOP_AXILITE_ADDR_LAYER_STRIDE_V_DATA              0x40
#define XFPGA_TOP_AXILITE_BITS_LAYER_STRIDE_V_DATA              2
#define XFPGA_TOP_AXILITE_ADDR_LAYER_PAD_DATA                   0x48
#define XFPGA_TOP_AXILITE_BITS_LAYER_PAD_DATA                   1
#define XFPGA_TOP_AXILITE_ADDR_LAYER_RELU_DATA                  0x50
#define XFPGA_TOP_AXILITE_BITS_LAYER_RELU_DATA                  1
#define XFPGA_TOP_AXILITE_ADDR_LAYER_IS_FIRST_SPLIT_LAYER_DATA  0x58
#define XFPGA_TOP_AXILITE_BITS_LAYER_IS_FIRST_SPLIT_LAYER_DATA  1
#define XFPGA_TOP_AXILITE_ADDR_LAYER_IS_SECOND_SPLIT_LAYER_DATA 0x60
#define XFPGA_TOP_AXILITE_BITS_LAYER_IS_SECOND_SPLIT_LAYER_DATA 1
#define XFPGA_TOP_AXILITE_ADDR_LAYER_GLOBAL_POOL_DATA           0x68
#define XFPGA_TOP_AXILITE_BITS_LAYER_GLOBAL_POOL_DATA           1
#define XFPGA_TOP_AXILITE_ADDR_LAYER_MEM_ADDR_INPUT_V_DATA      0x70
#define XFPGA_TOP_AXILITE_BITS_LAYER_MEM_ADDR_INPUT_V_DATA      23
#define XFPGA_TOP_AXILITE_ADDR_LAYER_MEM_ADDR_OUTPUT_V_DATA     0x78
#define XFPGA_TOP_AXILITE_BITS_LAYER_MEM_ADDR_OUTPUT_V_DATA     23
#define XFPGA_TOP_AXILITE_ADDR_LAYER_MEM_ADDR_WEIGHTS_V_DATA    0x80
#define XFPGA_TOP_AXILITE_BITS_LAYER_MEM_ADDR_WEIGHTS_V_DATA    23
#define XFPGA_TOP_AXILITE_ADDR_SHARED_DRAM_DATA                 0x88
#define XFPGA_TOP_AXILITE_BITS_SHARED_DRAM_DATA                 32
#define XFPGA_TOP_AXILITE_ADDR_WEIGHTS_OFFSET_DATA              0x90
#define XFPGA_TOP_AXILITE_BITS_WEIGHTS_OFFSET_DATA              32
#define XFPGA_TOP_AXILITE_ADDR_NUM_WEIGHTS_V_DATA               0x98
#define XFPGA_TOP_AXILITE_BITS_NUM_WEIGHTS_V_DATA               19
#define XFPGA_TOP_AXILITE_ADDR_INPUT_OFFSET_DATA                0xa0
#define XFPGA_TOP_AXILITE_BITS_INPUT_OFFSET_DATA                32
#define XFPGA_TOP_AXILITE_ADDR_LAYER_NAME_BASE                  0x10
#define XFPGA_TOP_AXILITE_ADDR_LAYER_NAME_HIGH                  0x17
#define XFPGA_TOP_AXILITE_WIDTH_LAYER_NAME                      8
#define XFPGA_TOP_AXILITE_DEPTH_LAYER_NAME                      7

